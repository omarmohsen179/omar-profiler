<?php
/**
 * Self-hosted contact-form handler for omarmohsen.dev — no third-party service.
 *
 * Sends form submissions by authenticating against your own cPanel mailbox over SMTP,
 * which gives reliable inbox delivery (Gmail trusts mail sent from your own domain).
 * A tiny built-in SMTP client is used, so there is NO library/composer dependency —
 * just upload this one file to public_html.
 *
 * SECURITY: this file runs as PHP on the server, so visitors CANNOT read its source
 * (they only ever see the JSON response). The password below is never sent to the browser.
 * Do NOT commit this file to a public git repo, and rotate the password if it leaks.
 *
 * ── Configuration ───────────────────────────────────────────────────────────
 */
$SMTP_HOST = 'mail.privateemail.com';      // your domain's mail is on Namecheap Private Email
                                           // (the MX record points to *.privateemail.com), so
                                           // this is the correct outgoing SMTP server.
$SMTP_PORT = 465;                          // 465 = implicit SSL (recommended). If it fails,
                                           // try 587 and set $SMTP_SECURE = 'tls' below.
$SMTP_SECURE = 'ssl';                      // 'ssl' for 465, 'tls' for 587
$SMTP_USER = 'contact@omarmohsen.dev';     // the mailbox that sends the email
$SMTP_PASS = 'Asas1212@';                  // its password  ⚠ rotate if this leaks
$FROM      = 'contact@omarmohsen.dev';     // From address (same as the mailbox)
$FROM_NAME = 'omarmohsen.dev';             // From display name
$RECIPIENT = 'contact@omarmohsen.dev';     // where you READ the messages — your on-domain
                                           // Private Email mailbox (webmail: privateemail.com)
// ─────────────────────────────────────────────────────────────────────────────

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// Honeypot — bots fill this hidden field, humans never do.
if (!empty($_POST['botcheck'])) {
    echo json_encode(['success' => true, 'message' => 'Thanks!']);
    exit;
}

$name    = trim($_POST['name']    ?? '');
$email   = trim($_POST['email']   ?? '');
$message = trim($_POST['message'] ?? '');

$ok = $name !== ''
   && filter_var($email, FILTER_VALIDATE_EMAIL)
   && $message !== ''
   && !preg_match('/[\r\n]/', $name . $email);  // block header injection

if (!$ok) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Please fill in all fields with a valid email.']);
    exit;
}

// Build the message
$subject = "New message from omarmohsen.dev — {$name}";
$body    = "You received a new message from your portfolio contact form.\n\n"
         . "Name:   {$name}\n"
         . "Email:  {$email}\n"
         . "----------------------------------------\n\n"
         . "{$message}\n";

$err = '';
$sent = smtp_send(
    $SMTP_HOST, $SMTP_PORT, $SMTP_SECURE, $SMTP_USER, $SMTP_PASS,
    $FROM, $FROM_NAME, $RECIPIENT, $name, $email, $subject, $body, $err
);

if ($sent) {
    echo json_encode(['success' => true, 'message' => 'Message sent.']);
} else {
    error_log('contact.php SMTP error: ' . $err);           // visible in cPanel error log only
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Could not send right now — please email me directly at ' . $RECIPIENT . '.',
    ]);
}

/**
 * Minimal SMTP client: connects, authenticates (AUTH LOGIN), and sends one message.
 * Returns true on success; on failure returns false and fills $err with the reason.
 */
function smtp_send($host, $port, $secure, $user, $pass, $from, $fromName,
                   $to, $replyName, $replyEmail, $subject, $body, &$err) {

    $transport = ($secure === 'ssl') ? "ssl://{$host}:{$port}" : "tcp://{$host}:{$port}";
    $ctx = stream_context_create(['ssl' => [
        // cPanel mail certs often don't match the exact host — the channel stays
        // encrypted, we just skip peer-name verification to avoid silent failures.
        'verify_peer'       => false,
        'verify_peer_name'  => false,
        'allow_self_signed' => true,
    ]]);

    $fp = @stream_socket_client($transport, $errno, $errstr, 20,
        STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) { $err = "connect failed: {$errstr} ({$errno})"; return false; }
    stream_set_timeout($fp, 20);

    $read = function () use ($fp) {
        $data = '';
        while (($line = fgets($fp, 515)) !== false) {
            $data .= $line;
            if (isset($line[3]) && $line[3] === ' ') break; // last line of a reply
        }
        return $data;
    };
    $cmd = function ($c) use ($fp) { fwrite($fp, $c . "\r\n"); };
    $expect = function ($resp, $code) use (&$err) {
        if (strncmp($resp, $code, 3) !== 0) { $err = 'SMTP: ' . trim($resp); return false; }
        return true;
    };

    if (!$expect($read(), '220')) return false;

    $cmd('EHLO omarmohsen.dev');
    $ehlo = $read();
    if (!$expect($ehlo, '250')) return false;

    // STARTTLS upgrade for port 587
    if ($secure === 'tls') {
        $cmd('STARTTLS');
        if (!$expect($read(), '220')) return false;
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            $err = 'STARTTLS negotiation failed'; return false;
        }
        $cmd('EHLO omarmohsen.dev');
        if (!$expect($read(), '250')) return false;
    }

    $cmd('AUTH LOGIN');
    if (!$expect($read(), '334')) return false;
    $cmd(base64_encode($user));
    if (!$expect($read(), '334')) return false;
    $cmd(base64_encode($pass));
    if (!$expect($read(), '235')) { $err = 'authentication failed'; return false; }

    $cmd("MAIL FROM:<{$from}>");
    if (!$expect($read(), '250')) return false;
    $cmd("RCPT TO:<{$to}>");
    if (!$expect($read(), '250')) return false;
    $cmd('DATA');
    if (!$expect($read(), '354')) return false;

    // Encode subject / names so non-ASCII (e.g. accented) characters survive.
    $encSubject   = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $encReplyName = '=?UTF-8?B?' . base64_encode($replyName) . '?=';

    $headers  = "From: {$fromName} <{$from}>\r\n";
    $headers .= "To: <{$to}>\r\n";
    $headers .= "Reply-To: {$encReplyName} <{$replyEmail}>\r\n";
    $headers .= "Subject: {$encSubject}\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
    $headers .= 'Date: ' . date('r') . "\r\n";

    // Dot-stuffing: a line that is just "." would end DATA early, so double leading dots.
    $safeBody = preg_replace('/^\./m', '..', $body);

    $cmd($headers . "\r\n" . $safeBody . "\r\n.");
    if (!$expect($read(), '250')) return false;

    $cmd('QUIT');
    fclose($fp);
    return true;
}
